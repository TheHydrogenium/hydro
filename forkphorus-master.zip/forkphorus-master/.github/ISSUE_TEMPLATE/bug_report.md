---
name: Bug report
about: Create a report to help us improve
title: "[Bug]"
labels: bug
assignees: ''

---

**Describe the bug, including any steps to reproduce it**


**Project ID, url, or file**


**Device Information (Device, Operating System, Browser)**


**Additional context or screenshots**
