---
name: Feature request
about: Suggest an idea for this project
title: "[Feature]"
labels: enhancement
assignees: ''

---

**Describe the feature you'd like to see**


**Describe what problem this feature would address**


**Additional context or screenshots**
